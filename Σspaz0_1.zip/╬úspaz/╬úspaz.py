import matplotlib.pyplot as plt
import numpy as np

filelist=[]

for i in range(1,5):
    filelist.append("k%s.txt" %i)


for fname in filelist:
    
    data=np.loadtxt(fname)
    #fig, (axi) = plt.subplots(nrows=i)

    #bins=np.arange(data.min(), data.max()+1)
    plt.hist(data, bins=10, histtype='stepfilled', facecolor='g', alpha=0.7)
    
    #design
    plt.title(fname)
    plt.xlabel('spaziatura (m)')
    plt.ylabel('frequenza')
    plt.grid(True)
    
    plt.show()

