import matplotlib.pyplot as plt
import numpy as np
    
#comma chekker
replacements = {',':'.'}
lines = []
for i in range(1,3):
    with open("k%s.txt" %i) as infile:
        for line in infile:
            for src, target in replacements.items():
                line = line.replace(src, target)
            lines.append(line)
    with open("k%s.txt" %i, 'w') as outfile:
        for line in lines:
            outfile.write(line)
            
#lista
filelist=[]

for i in range(1,5):
    filelist.append("k%s.txt" %i)

#graph
for fname in filelist:
    
    data=np.loadtxt(fname)
    #fig, (axi) = plt.subplots(nrows=i)

    #bins=np.arange(data.min(), data.max()+1)
    plt.hist(data, bins=11, histtype='stepfilled', facecolor='g', alpha=0.7)
    
    #design
    plt.title(fname)
    plt.xlabel('spaziatura (m)')
    plt.ylabel('frequenza')
    plt.grid(True)
    
    plt.show()

